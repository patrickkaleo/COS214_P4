#include "Task.h"
#include "TGIterator.h"
#include "StateIterator.h"
#include <stdexcept>

Task::Task(std::string desc) : description(desc), state(nullptr)
{
	state = new Design(this);
}

void Task::updateState(TaskState *newState, bool testPassed)
{
	TaskState *old = state;
	old->updateState(newState, testPassed);
	if (state != old)
		delete old;
}

void Task::add(Task *child)
{
	throw std::runtime_error("This task cannot have children added to it.");
}

Task::~Task() { delete state; }

void Task::setState(TaskState *newState)
{
	delete this->state;
}

void Task::logState() const
{
	std::cout << "Task: " << description << " | Status: " << (this->state ? state->state() : "null") << "\n";
}

TaskState *Task::getState() const
{
	return state;
}

std::string Task::getDescription() const { return this->description; }