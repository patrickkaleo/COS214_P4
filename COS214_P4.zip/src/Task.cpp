#include "Task.h"
#include "TGIterator.h"
#include "StateIterator.h"

Task::Task(std::string desc) : description(desc), state(nullptr) {
	state = new Design(this);
}

Task::~Task() { delete state; }

void Task::setState(TaskState *newState)
{
	if (this->state)
	{
		delete this->state;
	}
	state = newState;
}

void Task::logState() const
{
	std::cout << "Task: " << description << " | Status: " << (this->state ? state->state() : "null") << "\n";
}

TaskState* Task::getState() const {
	return state;
}

std::string Task::getDescription() const { return this->description; }