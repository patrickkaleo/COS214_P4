#include "UnitTask.h"
using namespace std;

UnitTask::UnitTask(string description) : Task(description){}